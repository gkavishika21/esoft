/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package rainbopreschool;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import javax.swing.JOptionPane;

/**
 *
 * @author ss
 */
public class DBCONNECTION {
    

    static Connection con ;
    
static void Connect (){
        try
        {
            String host = "jdbc:derby://localhost:1527/rainboDB";
             String usn = "pre";
             String pwd = "1234";
              con = DriverManager.getConnection(host,usn,pwd);
             // JOptionPane.showMessageDialog(null, "data base is sucsses full.");
             
             
             
        } 
        catch(SQLException ex){
            JOptionPane.showMessageDialog(null, ex);
        }
    
}}
